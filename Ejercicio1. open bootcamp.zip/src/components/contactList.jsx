import React from 'react';
import { Contact } from './contact.class';
import ContactComponent from './contactComponent';


const ContactList = () => {

    const contacto = new Contact('Romel','Zela','RomelZela@gmail.com', false);

  
    return (
      <div>
          <ContactComponent contact={contacto}/>
      </div>
    )
}

export default ContactList






